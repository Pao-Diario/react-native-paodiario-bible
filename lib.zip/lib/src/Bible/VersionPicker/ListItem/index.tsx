import React, { useState } from "react";
import * as Styled from "./styles";
import { downloadVersion, removeVersion } from "../../functions";
import useBible from "../../hooks/useBible";
export default function ListItem({
  version,
  active = false,
  offline = false,
  onSelect,
  selectedChapter = false,
  ...props
}: {
  version: any;
  active?: boolean;
  offline?: boolean;
  onSelect: any;
  selectedChapter?: boolean;
  [key: string]: any;
}) {
  const bibleContext = useBible();
  const [downloaded, setDownloaded] = useState(
    (bibleContext?.versionsOffline ?? []).findIndex(
      (versionOffline) => version.slug === versionOffline.slug
    ) > -1
  );
  const [downloading, setDownloading] = useState(false);
  const iconName = downloaded ? "check" : "chevron-down";
  async function downloadStart() {
    if (!downloading) {
      setDownloading(true);
      if (downloaded) {
        bibleContext?.updateContext({
          ...bibleContext,
          versionsOffline: await removeVersion({
            config: bibleContext,
            version,
          }),
        });
      }
      const retDownload = await downloadVersion({
        config: bibleContext,
        version,
      });
      if (retDownload) {
        if (retDownload.length > 0) {
          bibleContext?.updateContext({
            ...bibleContext,
            versionsOffline: retDownload,
          });
        }
        setDownloaded(true);
      }
      setDownloading(false);
    }
  }
  return React.createElement(
    Styled.OptionRow,
    { key: `picker_version_${version.slug}`, active: active },
    React.createElement(
      Styled.OptionButton,
      {
        onPress: () => {
          onSelect(version);
        },
      },
      React.createElement(
        Styled.OptionContainer,
        null,
        React.createElement(
          Styled.OptionValue,
          null,
          version.title,
          React.createElement(
            Styled.OptionLabel,
            null,
            `\r\n${version.fullName}`
          )
        ),
        React.createElement(
          Styled.VersionButton,
          {
            onPress: () => {
              downloadStart();
            },
          },
          downloading
            ? React.createElement(
                Styled.ActivityIndicatorDownloadingArea,
                null,
                React.createElement(Styled.ActivityIndicatorDownloading, null)
              )
            : React.createElement(
                Styled.VersionButtonContainer,
                { downloaded: downloaded },
                React.createElement(
                  Styled.VersionButtonIconContainer,
                  { downloaded: downloaded },
                  React.createElement(Styled.VersionButtonIcon, {
                    downloaded: downloaded,
                    name: iconName,
                  })
                ),
                React.createElement(
                  Styled.VersionButtonText,
                  { downloaded: downloaded },
                  `${downloaded ? "baixado" : "baixar"}`
                )
              )
        )
      )
    )
  );
}
