import React from "react";
type ReaderProps = {
    route?: any;
};
export default function Reader({ route }: ReaderProps): React.JSX.Element;
export {};
