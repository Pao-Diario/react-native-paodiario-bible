export const Container: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ViewProps, never>>;
export const Header: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ViewProps, never>>;
export const ContentList: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("styled-components/native/dist/types").FastOmit<import("styled-components/native/dist/types").Substitute<import("react-native").FlatListProps<unknown>, import("react-native").FlatListProps<unknown> & import("react").RefAttributes<import("react-native").FlatList<unknown>>>, never>, never>>;
export const HeaderGroup: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ViewProps, never>>;
export const HeaderButton: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TouchableOpacityProps, never>>;
export const HeaderIcon: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<{
    light?: boolean | undefined;
    solid?: boolean | undefined;
    brand?: boolean | undefined;
} & import("react-native-vector-icons/Icon").IconProps & import("react").RefAttributes<Icon>, never>>;
export const VerseArea: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("styled-components/native/dist/types").FastOmit<import("styled-components/native/dist/types").Substitute<import("react-native").TouchableOpacityProps, import("react-native").TouchableOpacityProps & import("react").RefAttributes<import("react-native").View>>, never>, never>>;
export const VerseNumber: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TextProps, never>>;
export const VerseText: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TextProps, never>>;
export const LoadingArea: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ViewProps, never>>;
export const Loading: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ActivityIndicatorProps, never>>;
export const NavigationButton: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TouchableOpacityProps, never>>;
export const NavigationIcon: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<{
    light?: boolean | undefined;
    solid?: boolean | undefined;
    brand?: boolean | undefined;
} & import("react-native-vector-icons/Icon").IconProps & import("react").RefAttributes<Icon>, never>>;
export const FontScaleContainer: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ViewProps, never>>;
export const FontDecreaseIcon: import("styled-components/native/dist/types").IStyledComponentBase<"native", any>;
export const FontIncreaseIcon: import("styled-components/native/dist/types").IStyledComponentBase<"native", any>;
import Icon from 'react-native-vector-icons/FontAwesome5';
