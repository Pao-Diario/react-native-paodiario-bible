import React, { ReactNode } from "react";
type BibleContextWrapperProps = {
    children: ReactNode;
};
export default function BibleContextWrapper({ children, }: BibleContextWrapperProps): React.JSX.Element;
export {};
