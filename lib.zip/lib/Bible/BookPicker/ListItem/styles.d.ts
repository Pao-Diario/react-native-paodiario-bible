export const Area: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("styled-components/native/dist/types").FastOmit<import("styled-components/native/dist/types").Substitute<import("react-native").TouchableOpacityProps, import("react-native").TouchableOpacityProps & import("react").RefAttributes<import("react-native").View>>, never>, never>>;
export const RowBtn: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ViewProps, never>>;
export const Title: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TextProps, never>>;
export const IconArrow: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<{
    light?: boolean | undefined;
    solid?: boolean | undefined;
    brand?: boolean | undefined;
} & import("react-native-vector-icons/Icon").IconProps & import("react").RefAttributes<Icon>, never>>;
export const RowChapters: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ViewProps, never>>;
export const ChapterButton: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TouchableOpacityProps, never>>;
export const ChapterButtonText: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TextProps, never>>;
import Icon from 'react-native-vector-icons/FontAwesome5';
