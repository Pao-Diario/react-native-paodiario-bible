export default function ListItem({ book, selected, onSelect, selectedChapter, ...props }: {
    [x: string]: any;
    book: any;
    selected: any;
    onSelect: any;
    selectedChapter: any;
}): React.JSX.Element;
import React from 'react';
