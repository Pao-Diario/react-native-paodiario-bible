import React from "react";
type BookPickerProps = {
    visible: boolean;
    verses?: any;
    onDismiss: (params?: any) => void;
    onBackButtonPress?: () => void;
    onSelect?: (book: any) => void;
    currentBook?: any;
    [key: string]: any;
};
export default function BookPicker({ visible, verses, onDismiss, onBackButtonPress, onSelect, currentBook, ...props }: BookPickerProps): React.JSX.Element;
export {};
