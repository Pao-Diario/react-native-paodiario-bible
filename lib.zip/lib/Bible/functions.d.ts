export declare function getBibleBooks(language?: string): any[];
export declare function getBibleBookChapters(book: {
    slug: string;
}): number;
export declare function getBibleVersions(): Array<{
    slug: string;
    title: string;
    fullName: string;
    language: string;
}>;
export declare function getBibleBySlug(slug: string): {
    slug: string;
    title: string;
    fullName: string;
    language: string;
} | undefined;
export declare function getLinkBook(config: {
    currentBookSlug: string;
    currentBookName: string;
    currentBookChapter: number;
}, type?: "next" | "prev"): Promise<{
    chapter: number;
    slug: string;
    title: string;
}>;
export declare function removeVersion({ config, version, }: {
    config: any;
    version: any;
}): Promise<any[]>;
export declare function openFile({ fileName, pathDir, }: {
    fileName: string;
    pathDir: string;
}): Promise<string | never[]>;
export declare function saveToFile({ content, fileName, pathDir, }: {
    content: string;
    fileName: string;
    pathDir: string;
}): Promise<void>;
export declare function downloadVersion({ config, version, }: {
    config: any;
    version: any;
}): Promise<false | any[]>;
export declare function loadBibleContent({ config, bookSlug, bookChapter, bookTitle, reference, }: any): Promise<any>;
