export type BibleContextType = {
    devotionalApiBaseUrl: string;
    fontSizeOffset: number;
    language: string;
    currentBookName: string;
    currentBookSlug: string;
    currentBookChapter: number;
    currentVersion: string;
    currentVersionTitle: string;
    versionsOffline: any[];
    updateContext: (config: any) => void;
};
export declare const BibleContext: import("react").Context<BibleContextType | null>;
export default function useBible(): BibleContextType | null;
