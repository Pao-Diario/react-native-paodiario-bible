import React from "react";
type BibleVersesModalProps = {
    visible: boolean;
    verses: string;
    onDismiss: () => void;
};
export default function BibleVersesModal({ visible, verses, onDismiss }: BibleVersesModalProps): React.JSX.Element;
export {};
