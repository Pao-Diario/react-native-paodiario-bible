interface DownloadedProps {
    downloaded: boolean;
}
interface ActiveProps {
    active: boolean;
}
import Icon from 'react-native-vector-icons/FontAwesome5';
export declare const VersionButton: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TouchableOpacityProps, never>>;
export declare const ActivityIndicatorDownloadingArea: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ViewProps, never>>;
export declare const ActivityIndicatorDownloading: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ActivityIndicatorProps, never>>;
export declare const VersionButtonContainer: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").Substitute<import("react-native").ViewProps, DownloadedProps>>;
export declare const VersionButtonIconContainer: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").Substitute<import("react-native").ViewProps, DownloadedProps>>;
export declare const VersionButtonIcon: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").Substitute<{
    light?: boolean | undefined;
    solid?: boolean | undefined;
    brand?: boolean | undefined;
} & import("react-native-vector-icons/Icon").IconProps & import("react").RefAttributes<Icon>, DownloadedProps>>;
export declare const VersionButtonText: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").Substitute<import("react-native").TextProps, DownloadedProps>>;
export declare const OptionRow: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").Substitute<import("react-native").ViewProps, ActiveProps>>;
export declare const OptionButton: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TouchableOpacityProps, never>>;
export declare const OptionTitle: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TextProps, never>>;
export declare const OptionContainer: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").ViewProps, never>>;
export declare const OptionLabel: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TextProps, never>>;
export declare const OptionValue: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<import("react-native").TextProps, never>>;
export declare const OptionIcon: import("styled-components/native/dist/types").IStyledComponentBase<"native", import("styled-components/native/dist/types").FastOmit<{
    light?: boolean | undefined;
    solid?: boolean | undefined;
    brand?: boolean | undefined;
} & import("react-native-vector-icons/Icon").IconProps & import("react").RefAttributes<Icon>, never>>;
export {};
