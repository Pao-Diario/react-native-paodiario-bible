import React from "react";
type BibleVersion = {
    slug: string;
    title: string;
    fullName: string;
    language: string;
};
interface ListItemProps {
    version: BibleVersion;
    active?: boolean;
    offline?: boolean;
    onSelect: (version: BibleVersion) => void;
    selectedChapter?: boolean;
    [key: string]: any;
}
export default function ListItem({ version, active, offline, onSelect, selectedChapter, ...props }: ListItemProps): React.JSX.Element;
export {};
