import React from "react";
type VersionPickerProps = {
    visible: boolean;
    onDismiss: () => void;
    onBackButtonPress?: () => void;
    onSelect?: (version: any) => void;
    [key: string]: any;
};
export default function VersionPicker({ visible, onDismiss, onBackButtonPress, onSelect, ...props }: VersionPickerProps): React.JSX.Element;
export {};
