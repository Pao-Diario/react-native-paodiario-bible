import React from "react";
type CardBIYProps = {
    verses: string[];
    [key: string]: any;
};
export default function CardBIY({ verses, ...props }: CardBIYProps): React.JSX.Element;
export {};
