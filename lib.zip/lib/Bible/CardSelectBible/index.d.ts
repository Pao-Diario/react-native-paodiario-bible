import React from "react";
type CardSelectBibleProps = {
    title?: string;
    bordered?: boolean;
    showReadButton?: boolean;
    boookSelected?: (book: any) => void;
    [key: string]: any;
};
export default function CardSelectBible({ title, bordered, showReadButton, boookSelected, ...props }: CardSelectBibleProps): React.JSX.Element;
export {};
