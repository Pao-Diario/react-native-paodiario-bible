import React from "react";
type VerseOfTheDayProps = {
    verse: string;
    [key: string]: any;
};
export default function VerseOfTheDay({ verse, ...props }: VerseOfTheDayProps): React.JSX.Element;
export {};
