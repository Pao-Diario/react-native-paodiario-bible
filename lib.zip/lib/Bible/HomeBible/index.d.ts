import React from "react";
export default function HomeBible(): React.JSX.Element;
