export function formatElapsedTime(input: any): string;
export function replaceSpecialChars(str: any): any;
export function pluralize(text: any, quantity?: number): string;
export function normalize(input: any): any;
export function getIDFromURL(url: any): any;
export function getPlaylistIDFromURL(url: any): any;
export function capitalizeFirstLetter(string: any): any;
export function trim(text: any): any;
