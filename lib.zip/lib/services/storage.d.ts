export declare function persist(key: string, value: any, format?: string): Promise<void>;
export declare function get(key: string, format?: string): Promise<any>;
