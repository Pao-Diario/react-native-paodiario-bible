export function getUploadURL(path: any): string;
export const BaseUrl: "https://universitarios.app.paodiario.org.br/";
export const devotionalsAPI: import("axios").AxiosInstance;
export const apiToken: "bc7e8aba-dd5b-47c7-a8a6-2adf3c5c72bc6";
export const bibleApi: import("axios").AxiosInstance;
export default api;
declare const api: import("axios").AxiosInstance;
